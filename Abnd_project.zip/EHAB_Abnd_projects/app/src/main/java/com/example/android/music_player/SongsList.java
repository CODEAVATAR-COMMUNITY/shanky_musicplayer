package com.example.android.music_player;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;

public class SongsList extends AppCompatActivity implements AdapterView.OnItemClickListener {
    GridView gridview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.songs_list);
        gridview = findViewById(R.id.gridview);
        gridview.setAdapter(new MyAdapter(this));
    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
        //Things need to be done , passing view on item click to music player activity(soonly be made).
    }
}
