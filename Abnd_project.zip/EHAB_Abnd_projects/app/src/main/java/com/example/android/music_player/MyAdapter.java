package com.example.android.music_player;

import android.content.Context;
import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

class MyAdapter extends BaseAdapter {
    Context context;
    ArrayList<Song> songList;

    public MyAdapter(Context context) {
        this.context = context;
        songList = new ArrayList<Song>();
        Resources res = context.getResources();
        String[] temp = res.getStringArray(R.array.songs);
        int[] images = {R.drawable.songimage1, R.drawable.songimage2, R.drawable.songimage3, R.drawable.songimage4, R.drawable.songimage5, R.drawable.th6, R.drawable.th7, R.drawable.th8, R.drawable.th9, R.drawable.th10};
        for (int i = 0; i < 10; i++) {
            Song DataTemp = new Song(images[i], temp[i]);
            songList.add(DataTemp);
        }
    }

    @Override
    public int getCount() {
        return songList.size();
    }

    @Override
    public Object getItem(int position) {
        return songList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder;
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.songview, parent, false);
            viewHolder = new ViewHolder(convertView);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }

        Song stemp = (Song) getItem(position);
        viewHolder.mySongImage.setImageResource(stemp.imageofsong());
        viewHolder.mySongText.setText(stemp.nameofsong());

        return convertView;
    }

    class ViewHolder {
        ImageView mySongImage;
        TextView mySongText;

        ViewHolder(View v) {
            mySongImage = v.findViewById(R.id.gridimage);
            mySongText = v.findViewById(R.id.gridtext);
        }
    }
}
